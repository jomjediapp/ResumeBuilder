const STORAGE_KEY = "applicant-resume-builder";

const form = document.querySelector("#resumeForm");
const experienceList = document.querySelector("#experienceList");
const educationList = document.querySelector("#educationList");
const saveStatus = document.querySelector("#saveStatus");
const resumePreview = document.querySelector("#resumePreview");
const aiStatus = document.querySelector("#aiStatus");
const sheetStatus = document.querySelector("#sheetStatus");
const sheetEndpoint = document.querySelector("#sheetEndpoint");

const defaultData = {
  fullName: "",
  jobTitle: "",
  email: "",
  phone: "",
  location: "",
  website: "",
  summary: "",
  skills: "",
  extras: "",
  accentColor: "#1e6f5c",
  compactMode: false,
  experience: [
    { title: "", company: "", start: "", end: "", details: "" }
  ],
  education: [
    { degree: "", school: "", year: "", place: "" }
  ]
};

const sampleData = {
  fullName: "Maya Chen",
  jobTitle: "Customer Success Specialist",
  email: "maya.chen@example.com",
  phone: "+1 555 0188",
  location: "Seattle, WA",
  website: "https://linkedin.com/in/mayachen",
  summary: "Customer success professional with 5 years of experience onboarding SaaS customers, reducing churn, and turning feedback into product improvements. Known for clear communication, practical training programs, and calm issue resolution.",
  skills: "Customer onboarding, account management, Salesforce, product training, renewal strategy, data reporting",
  extras: "Certified Customer Success Manager, English and Mandarin",
  accentColor: "#1e6f5c",
  compactMode: false,
  experience: [
    {
      title: "Customer Success Specialist",
      company: "Northstar Software",
      start: "Mar 2022",
      end: "Present",
      details: "Guided 48 enterprise customers through onboarding with a 94% activation rate.\nReduced support escalations by 22% by creating training playbooks and office-hour sessions.\nPartnered with product managers to prioritize customer feedback for quarterly releases."
    },
    {
      title: "Client Support Associate",
      company: "BrightDesk",
      start: "Jun 2019",
      end: "Feb 2022",
      details: "Resolved an average of 35 support tickets per day while maintaining a 4.8 customer rating.\nBuilt dashboard templates that helped account managers identify renewal risks earlier."
    }
  ],
  education: [
    {
      degree: "B.A. Business Administration",
      school: "University of Washington",
      year: "2019",
      place: "Seattle, WA"
    }
  ]
};

const resumeSchema = {
  type: "object",
  additionalProperties: false,
  properties: {
    fullName: { type: "string" },
    jobTitle: { type: "string" },
    email: { type: "string" },
    phone: { type: "string" },
    location: { type: "string" },
    website: { type: "string" },
    summary: { type: "string" },
    skills: { type: "string" },
    extras: { type: "string" },
    experience: {
      type: "array",
      items: {
        type: "object",
        additionalProperties: false,
        properties: {
          title: { type: "string" },
          company: { type: "string" },
          start: { type: "string" },
          end: { type: "string" },
          details: { type: "string" }
        },
        required: ["title", "company", "start", "end", "details"]
      }
    },
    education: {
      type: "array",
      items: {
        type: "object",
        additionalProperties: false,
        properties: {
          degree: { type: "string" },
          school: { type: "string" },
          year: { type: "string" },
          place: { type: "string" }
        },
        required: ["degree", "school", "year", "place"]
      }
    }
  },
  required: [
    "fullName",
    "jobTitle",
    "email",
    "phone",
    "location",
    "website",
    "summary",
    "skills",
    "extras",
    "experience",
    "education"
  ]
};

function cloneData(data) {
  return JSON.parse(JSON.stringify(data));
}

function setAiStatus(message, isError = false) {
  aiStatus.textContent = message;
  aiStatus.style.color = isError ? "#8b2f2b" : "";
}

function setSheetStatus(message, isError = false) {
  sheetStatus.textContent = message;
  sheetStatus.style.color = isError ? "#8b2f2b" : "";
}

function fileToDataUrl(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.addEventListener("load", () => resolve(reader.result));
    reader.addEventListener("error", reject);
    reader.readAsDataURL(file);
  });
}

function fileToText(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.addEventListener("load", () => resolve(reader.result));
    reader.addEventListener("error", reject);
    reader.readAsText(file);
  });
}

function createRepeatItem(kind, values = {}) {
  const template = document.querySelector(`#${kind}Template`);
  const node = template.content.firstElementChild.cloneNode(true);
  Object.entries(values).forEach(([field, value]) => {
    const input = node.querySelector(`[data-field="${field}"]`);
    if (input) input.value = value;
  });
  node.querySelector(".remove-button").addEventListener("click", () => {
    node.remove();
    ensureOneItem(kind);
    updateResume();
  });
  node.addEventListener("input", updateResume);
  return node;
}

function ensureOneItem(kind) {
  const list = kind === "experience" ? experienceList : educationList;
  if (!list.children.length) {
    list.append(createRepeatItem(kind, cloneData(defaultData[kind][0])));
  }
}

function getRepeatData(kind) {
  const list = kind === "experience" ? experienceList : educationList;
  return [...list.querySelectorAll(".repeat-item")].map((item) => {
    const values = {};
    item.querySelectorAll("[data-field]").forEach((field) => {
      values[field.dataset.field] = field.value.trim();
    });
    return values;
  });
}

function getFormData() {
  const data = new FormData(form);
  return {
    fullName: data.get("fullName").trim(),
    jobTitle: data.get("jobTitle").trim(),
    email: data.get("email").trim(),
    phone: data.get("phone").trim(),
    location: data.get("location").trim(),
    website: data.get("website").trim(),
    summary: data.get("summary").trim(),
    skills: data.get("skills").trim(),
    extras: data.get("extras").trim(),
    accentColor: data.get("accentColor") || defaultData.accentColor,
    compactMode: data.get("compactMode") === "on",
    experience: getRepeatData("experience"),
    education: getRepeatData("education")
  };
}

function setFormData(data) {
  const merged = { ...cloneData(defaultData), ...data };
  Object.entries(merged).forEach(([key, value]) => {
    const field = form.elements[key];
    if (!field || Array.isArray(value)) return;
    if (field.type === "checkbox") {
      field.checked = Boolean(value);
    } else {
      field.value = value;
    }
  });

  experienceList.replaceChildren(
    ...merged.experience.map((item) => createRepeatItem("experience", item))
  );
  educationList.replaceChildren(
    ...merged.education.map((item) => createRepeatItem("education", item))
  );

  ensureOneItem("experience");
  ensureOneItem("education");
  updateResume(false);
}

function applyExtractedData(data) {
  const current = getFormData();
  const cleaned = {
    ...current,
    ...data,
    accentColor: current.accentColor,
    compactMode: current.compactMode,
    experience: Array.isArray(data.experience) && data.experience.length
      ? data.experience
      : current.experience,
    education: Array.isArray(data.education) && data.education.length
      ? data.education
      : current.education
  };
  setFormData(cleaned);
  persist(getFormData());
}

function setText(selector, value, fallback) {
  const element = document.querySelector(selector);
  element.textContent = value || fallback;
}

function listFromLines(text) {
  return text
    .split("\n")
    .map((line) => line.trim())
    .filter(Boolean);
}

function commaList(text) {
  return text
    .split(/,|\n/)
    .map((item) => item.trim())
    .filter(Boolean);
}

function renderContact(data) {
  const contact = [
    data.email,
    data.phone,
    data.location,
    data.website
  ].filter(Boolean);
  document.querySelector("#previewContact").replaceChildren(
    ...contact.map((item) => {
      const li = document.createElement("li");
      li.textContent = item;
      return li;
    })
  );
}

function renderExperience(items) {
  const visibleItems = items.filter((item) =>
    Object.values(item).some(Boolean)
  );
  const container = document.querySelector("#previewExperience");

  if (!visibleItems.length) {
    container.innerHTML = '<p class="empty-note">Add roles, companies, dates, and achievement bullets.</p>';
    return;
  }

  container.replaceChildren(
    ...visibleItems.map((item) => {
      const article = document.createElement("article");
      article.className = "resume-item";

      const title = document.createElement("h4");
      title.textContent = [item.title, item.company].filter(Boolean).join(" at ") || "Role";

      const meta = document.createElement("div");
      meta.className = "resume-meta";
      meta.textContent = [item.start, item.end].filter(Boolean).join(" - ");

      const bullets = document.createElement("ul");
      listFromLines(item.details).forEach((line) => {
        const li = document.createElement("li");
        li.textContent = line;
        bullets.append(li);
      });

      article.append(title);
      if (meta.textContent) article.append(meta);
      if (bullets.children.length) article.append(bullets);
      return article;
    })
  );
}

function renderEducation(items) {
  const visibleItems = items.filter((item) =>
    Object.values(item).some(Boolean)
  );
  const container = document.querySelector("#previewEducation");

  if (!visibleItems.length) {
    container.innerHTML = '<p class="empty-note">Add your degree, institution, year, and location.</p>';
    return;
  }

  container.replaceChildren(
    ...visibleItems.map((item) => {
      const article = document.createElement("article");
      article.className = "resume-item";

      const title = document.createElement("h4");
      title.textContent = item.degree || "Program";

      const meta = document.createElement("div");
      meta.className = "resume-meta";
      meta.textContent = [item.school, item.place, item.year].filter(Boolean).join(" | ");

      article.append(title);
      if (meta.textContent) article.append(meta);
      return article;
    })
  );
}

function renderSkills(skills) {
  const container = document.querySelector("#previewSkills");
  const tags = commaList(skills);

  if (!tags.length) {
    container.innerHTML = '<p class="empty-note">Add skills separated by commas or new lines.</p>';
    return;
  }

  container.replaceChildren(
    ...tags.map((skill) => {
      const span = document.createElement("span");
      span.className = "skill-tag";
      span.textContent = skill;
      return span;
    })
  );
}

function persist(data) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
  saveStatus.textContent = "Saved locally";
}

function persistSheetEndpoint() {
  localStorage.setItem(`${STORAGE_KEY}-sheet-endpoint`, sheetEndpoint.value.trim());
}

function updateResume(shouldPersist = true) {
  const data = getFormData();

  setText('[data-preview="fullName"]', data.fullName, "Your Name");
  setText('[data-preview="jobTitle"]', data.jobTitle, "Target role");
  setText(
    '[data-preview="summary"]',
    data.summary,
    "Add a short professional summary to introduce your experience and goals."
  );
  setText('[data-preview="extras"]', data.extras, "");

  renderContact(data);
  renderExperience(data.experience);
  renderEducation(data.education);
  renderSkills(data.skills);

  resumePreview.style.setProperty("--resume-accent", data.accentColor);
  resumePreview.classList.toggle("compact", data.compactMode);

  document.querySelector('[data-section="extras"]').hidden = !data.extras;
  if (shouldPersist) persist(data);
}

function loadStoredData() {
  try {
    return JSON.parse(localStorage.getItem(STORAGE_KEY)) || cloneData(defaultData);
  } catch {
    return cloneData(defaultData);
  }
}

function getOutputText(response) {
  if (response.output_text) return response.output_text;
  return (response.output || [])
    .flatMap((item) => item.content || [])
    .map((content) => content.text || "")
    .join("\n")
    .trim();
}

function buildLocalExtraction(text) {
  const lines = text
    .split(/\r?\n/)
    .map((line) => line.trim())
    .filter(Boolean);
  const email = text.match(/[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/i)?.[0] || "";
  const phone = text.match(/(?:\+?\d[\d\s().-]{7,}\d)/)?.[0] || "";
  const website = text.match(/https?:\/\/[^\s]+|linkedin\.com\/[^\s]+/i)?.[0] || "";
  const name = lines.find((line) => !line.includes("@") && !/\d/.test(line)) || "";
  const summaryStart = lines.findIndex((line) => /summary|profile|objective/i.test(line));
  const skillsStart = lines.findIndex((line) => /skills|technologies|competencies/i.test(line));

  return {
    fullName: name,
    jobTitle: lines[1] && lines[1] !== email ? lines[1] : "",
    email,
    phone,
    location: "",
    website,
    summary: summaryStart >= 0 ? lines.slice(summaryStart + 1, summaryStart + 4).join(" ") : "",
    skills: skillsStart >= 0 ? lines.slice(skillsStart + 1, skillsStart + 4).join(", ") : "",
    extras: "",
    experience: [],
    education: []
  };
}

async function extractWithOpenAi() {
  const apiKey = document.querySelector("#apiKey").value.trim();
  const model = document.querySelector("#aiModel").value.trim() || "gpt-5";
  const file = document.querySelector("#resumeUpload").files[0];
  const pastedText = document.querySelector("#resumeTextImport").value.trim();

  if (!apiKey) {
    setAiStatus("Enter an OpenAI API key to extract with AI.", true);
    return;
  }

  if (!file && !pastedText) {
    setAiStatus("Upload a resume file or paste resume text first.", true);
    return;
  }

  setAiStatus("Reading resume input...");

  const content = [
    {
      type: "input_text",
      text: "Extract resume information from the applicant material. Return concise, polished resume-ready data. Put each experience achievement on its own line in details. If a field is missing, use an empty string."
    }
  ];

  if (pastedText) {
    content.push({ type: "input_text", text: pastedText });
  }

  if (file) {
    const dataUrl = await fileToDataUrl(file);
    if (file.type.startsWith("image/")) {
      content.push({ type: "input_image", image_url: dataUrl });
    } else {
      content.push({
        type: "input_file",
        filename: file.name,
        file_data: dataUrl
      });
    }
  }

  setAiStatus("Asking AI to extract resume details...");

  const response = await fetch("https://api.openai.com/v1/responses", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "Authorization": `Bearer ${apiKey}`
    },
    body: JSON.stringify({
      model,
      input: [{ role: "user", content }],
      text: {
        format: {
          type: "json_schema",
          name: "resume_details",
          schema: resumeSchema,
          strict: true
        }
      }
    })
  });

  const result = await response.json();
  if (!response.ok) {
    throw new Error(result.error?.message || "The AI extraction request failed.");
  }

  const extracted = JSON.parse(getOutputText(result));
  applyExtractedData(extracted);
  setAiStatus("Resume details extracted and applied.");
}

document.querySelector("#addExperience").addEventListener("click", () => {
  experienceList.append(createRepeatItem("experience"));
  updateResume();
});

document.querySelector("#addEducation").addEventListener("click", () => {
  educationList.append(createRepeatItem("education"));
  updateResume();
});

document.querySelector("#loadSample").addEventListener("click", () => {
  setFormData(cloneData(sampleData));
  persist(getFormData());
});

document.querySelector("#clearForm").addEventListener("click", () => {
  if (confirm("Clear all resume details?")) {
    localStorage.removeItem(STORAGE_KEY);
    setFormData(cloneData(defaultData));
  }
});

document.querySelector("#printResume").addEventListener("click", () => {
  window.print();
});

document.querySelector("#sendToSheet").addEventListener("click", async () => {
  const endpoint = sheetEndpoint.value.trim();
  const consent = document.querySelector("#sheetConsent").checked;

  if (!endpoint) {
    setSheetStatus("Paste your Google Apps Script web app URL first.", true);
    return;
  }

  if (!consent) {
    setSheetStatus("Confirm applicant consent before sending resume details.", true);
    return;
  }

  setSheetStatus("Sending resume details...");
  persistSheetEndpoint();

  try {
    const response = await fetch(endpoint, {
      method: "POST",
      mode: "no-cors",
      headers: { "Content-Type": "text/plain;charset=utf-8" },
      body: JSON.stringify({
        submittedAt: new Date().toISOString(),
        source: window.location.href,
        resume: getFormData()
      })
    });

    if (response.type !== "opaque" && !response.ok) {
      throw new Error("Google Sheets rejected the submission.");
    }

    setSheetStatus("Submitted to Google Sheet.");
  } catch (error) {
    setSheetStatus(error.message || "Could not submit to Google Sheet.", true);
  }
});

document.querySelector("#extractWithAi").addEventListener("click", async () => {
  try {
    await extractWithOpenAi();
  } catch (error) {
    setAiStatus(error.message, true);
  }
});

document.querySelector("#extractFromText").addEventListener("click", async () => {
  const file = document.querySelector("#resumeUpload").files[0];
  let text = document.querySelector("#resumeTextImport").value.trim();

  if (!text && file && (/^text\/|json|csv|markdown/.test(file.type) || /\.(txt|md|json|csv)$/i.test(file.name))) {
    text = await fileToText(file);
  }

  if (!text) {
    setAiStatus("Paste text or upload a text-based file for local extraction.", true);
    return;
  }

  applyExtractedData(buildLocalExtraction(text));
  setAiStatus("Basic details pulled from text. Review and refine the sections.");
});

document.querySelectorAll(".step").forEach((button) => {
  button.addEventListener("click", () => {
    document.querySelectorAll(".step").forEach((step) => {
      step.classList.toggle("is-active", step === button);
    });
    document.querySelector(`#${button.dataset.target}`).scrollIntoView({
      behavior: "smooth",
      block: "start"
    });
  });
});

form.addEventListener("input", () => {
  saveStatus.textContent = "Saving...";
  updateResume();
});

sheetEndpoint.value = localStorage.getItem(`${STORAGE_KEY}-sheet-endpoint`) || "";
sheetEndpoint.addEventListener("input", persistSheetEndpoint);

setFormData(loadStoredData());
