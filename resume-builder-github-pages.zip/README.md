# Applicant Resume Builder

A static resume-builder app that lets applicants fill in resume details manually or import an existing resume file/image for AI extraction.

## GitHub Pages Deployment

1. Create a new GitHub repository.
2. Upload `index.html`, `styles.css`, `app.js`, `.nojekyll`, and this `README.md`.
3. Open the repository's **Settings**.
4. Go to **Pages**.
5. Under **Build and deployment**, choose **Deploy from a branch**.
6. Select the `main` branch and `/ (root)`, then save.

GitHub will publish the app at:

`https://YOUR_USERNAME.github.io/YOUR_REPOSITORY_NAME/`

## Google Sheets Collection

1. Create a Google Sheet.
2. Open **Extensions > Apps Script**.
3. Paste the contents of `google-apps-script.gs`.
4. Save the project.
5. Click **Deploy > New deployment**.
6. Choose **Web app**.
7. Set **Execute as** to `Me`.
8. Set **Who has access** to `Anyone`.
9. Deploy and copy the web app URL.
10. Paste that URL into the app's **Collect data** section.

Applicants must check the consent box before submitting resume details to the sheet.
