const SHEET_NAME = "Resume Submissions";

function doPost(e) {
  const sheet = getSheet();
  const payload = JSON.parse(e.postData.contents);
  const resume = payload.resume || {};

  sheet.appendRow([
    payload.submittedAt || new Date().toISOString(),
    payload.source || "",
    resume.fullName || "",
    resume.jobTitle || "",
    resume.email || "",
    resume.phone || "",
    resume.location || "",
    resume.website || "",
    resume.summary || "",
    resume.skills || "",
    resume.extras || "",
    JSON.stringify(resume.experience || []),
    JSON.stringify(resume.education || [])
  ]);

  return ContentService
    .createTextOutput(JSON.stringify({ ok: true }))
    .setMimeType(ContentService.MimeType.JSON);
}

function getSheet() {
  const spreadsheet = SpreadsheetApp.getActiveSpreadsheet();
  let sheet = spreadsheet.getSheetByName(SHEET_NAME);

  if (!sheet) {
    sheet = spreadsheet.insertSheet(SHEET_NAME);
    sheet.appendRow([
      "Submitted At",
      "Source",
      "Full Name",
      "Job Title",
      "Email",
      "Phone",
      "Location",
      "Website",
      "Summary",
      "Skills",
      "Extras",
      "Experience JSON",
      "Education JSON"
    ]);
  }

  return sheet;
}
